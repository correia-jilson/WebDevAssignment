# WebDevAssignment
INFO6150 35479 Web Design/User Experien Engr SEC 05 Spring 2024 [BOS-2-TR] Assignments

this website is my portfolio website
i have many of my details in various divisions and containers and cards.
a small video about myself and my social media accounts
various ways to contact me and connect with me 
at the end my personal phone details and my current place of work/study/operation
